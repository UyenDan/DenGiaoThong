﻿namespace Baitap_t3
{
    partial class Control
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.pnl_quanli = new System.Windows.Forms.Panel();
            this.pnl_setting = new System.Windows.Forms.Panel();
            this.pnl_Setting1 = new System.Windows.Forms.Label();
            this.pnl_help = new System.Windows.Forms.Panel();
            this.pnl_help1 = new System.Windows.Forms.Label();
            this.btn_On1 = new System.Windows.Forms.Button();
            this.pnl_Control1 = new System.Windows.Forms.Panel();
            this.DenGiaoThong1 = new System.Windows.Forms.Label();
            this.btn_Off2 = new System.Windows.Forms.Button();
            this.pnl_Red1 = new System.Windows.Forms.Label();
            this.pnl_Yellow1 = new System.Windows.Forms.Label();
            this.btn_Off3 = new System.Windows.Forms.Button();
            this.btn_On4 = new System.Windows.Forms.Button();
            this.pnl_Green1 = new System.Windows.Forms.Label();
            this.btn_Off5 = new System.Windows.Forms.Button();
            this.btn_On5 = new System.Windows.Forms.Button();
            this.pnl_Control2 = new System.Windows.Forms.Panel();
            this.btn_On7 = new System.Windows.Forms.Button();
            this.btn_Off8 = new System.Windows.Forms.Button();
            this.pnl_Green2 = new System.Windows.Forms.Label();
            this.btn_On9 = new System.Windows.Forms.Button();
            this.btn_Off7 = new System.Windows.Forms.Button();
            this.pnl_Yellow2 = new System.Windows.Forms.Label();
            this.pnl_red2 = new System.Windows.Forms.Label();
            this.btn_Off6 = new System.Windows.Forms.Button();
            this.DenGiaoThong2 = new System.Windows.Forms.Label();
            this.btn_On6 = new System.Windows.Forms.Button();
            this.pnl_quanli.SuspendLayout();
            this.pnl_setting.SuspendLayout();
            this.pnl_help.SuspendLayout();
            this.pnl_Control1.SuspendLayout();
            this.pnl_Control2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_quanli
            // 
            this.pnl_quanli.BackColor = System.Drawing.Color.SlateGray;
            this.pnl_quanli.Controls.Add(this.pnl_help);
            this.pnl_quanli.Controls.Add(this.pnl_setting);
            this.pnl_quanli.Location = new System.Drawing.Point(0, 0);
            this.pnl_quanli.Name = "pnl_quanli";
            this.pnl_quanli.Size = new System.Drawing.Size(1039, 150);
            this.pnl_quanli.TabIndex = 0;
            // 
            // pnl_setting
            // 
            this.pnl_setting.BackColor = System.Drawing.Color.AliceBlue;
            this.pnl_setting.Controls.Add(this.pnl_Setting1);
            this.pnl_setting.Location = new System.Drawing.Point(58, 21);
            this.pnl_setting.Name = "pnl_setting";
            this.pnl_setting.Size = new System.Drawing.Size(247, 110);
            this.pnl_setting.TabIndex = 0;
            this.pnl_setting.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // pnl_Setting1
            // 
            this.pnl_Setting1.AutoSize = true;
            this.pnl_Setting1.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pnl_Setting1.Location = new System.Drawing.Point(64, 36);
            this.pnl_Setting1.Name = "pnl_Setting1";
            this.pnl_Setting1.Size = new System.Drawing.Size(112, 36);
            this.pnl_Setting1.TabIndex = 0;
            this.pnl_Setting1.Text = "Setting";
            // 
            // pnl_help
            // 
            this.pnl_help.BackColor = System.Drawing.Color.AliceBlue;
            this.pnl_help.Controls.Add(this.pnl_help1);
            this.pnl_help.Location = new System.Drawing.Point(734, 21);
            this.pnl_help.Name = "pnl_help";
            this.pnl_help.Size = new System.Drawing.Size(247, 110);
            this.pnl_help.TabIndex = 1;
            // 
            // pnl_help1
            // 
            this.pnl_help1.AutoSize = true;
            this.pnl_help1.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pnl_help1.Location = new System.Drawing.Point(83, 36);
            this.pnl_help1.Name = "pnl_help1";
            this.pnl_help1.Size = new System.Drawing.Size(81, 36);
            this.pnl_help1.TabIndex = 0;
            this.pnl_help1.Text = "Help";
            // 
            // btn_On1
            // 
            this.btn_On1.Location = new System.Drawing.Point(246, 81);
            this.btn_On1.Name = "btn_On1";
            this.btn_On1.Size = new System.Drawing.Size(60, 34);
            this.btn_On1.TabIndex = 1;
            this.btn_On1.Text = "On";
            this.btn_On1.UseVisualStyleBackColor = true;
            this.btn_On1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pnl_Control1
            // 
            this.pnl_Control1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pnl_Control1.Controls.Add(this.btn_On5);
            this.pnl_Control1.Controls.Add(this.btn_Off5);
            this.pnl_Control1.Controls.Add(this.pnl_Green1);
            this.pnl_Control1.Controls.Add(this.btn_On4);
            this.pnl_Control1.Controls.Add(this.btn_Off3);
            this.pnl_Control1.Controls.Add(this.pnl_Yellow1);
            this.pnl_Control1.Controls.Add(this.pnl_Red1);
            this.pnl_Control1.Controls.Add(this.btn_Off2);
            this.pnl_Control1.Controls.Add(this.DenGiaoThong1);
            this.pnl_Control1.Controls.Add(this.btn_On1);
            this.pnl_Control1.Location = new System.Drawing.Point(43, 196);
            this.pnl_Control1.Name = "pnl_Control1";
            this.pnl_Control1.Size = new System.Drawing.Size(367, 307);
            this.pnl_Control1.TabIndex = 2;
            // 
            // DenGiaoThong1
            // 
            this.DenGiaoThong1.AutoSize = true;
            this.DenGiaoThong1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.DenGiaoThong1.Location = new System.Drawing.Point(38, 16);
            this.DenGiaoThong1.Name = "DenGiaoThong1";
            this.DenGiaoThong1.Size = new System.Drawing.Size(295, 41);
            this.DenGiaoThong1.TabIndex = 0;
            this.DenGiaoThong1.Text = "Den Giao Thong 1";
            this.DenGiaoThong1.Click += new System.EventHandler(this.DenGiaoThong_Click);
            // 
            // btn_Off2
            // 
            this.btn_Off2.ForeColor = System.Drawing.Color.Red;
            this.btn_Off2.Location = new System.Drawing.Point(154, 81);
            this.btn_Off2.Name = "btn_Off2";
            this.btn_Off2.Size = new System.Drawing.Size(60, 34);
            this.btn_Off2.TabIndex = 2;
            this.btn_Off2.Text = "OFF";
            this.btn_Off2.UseVisualStyleBackColor = true;
            // 
            // pnl_Red1
            // 
            this.pnl_Red1.AutoSize = true;
            this.pnl_Red1.BackColor = System.Drawing.Color.Red;
            this.pnl_Red1.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pnl_Red1.Location = new System.Drawing.Point(64, 86);
            this.pnl_Red1.Name = "pnl_Red1";
            this.pnl_Red1.Size = new System.Drawing.Size(49, 25);
            this.pnl_Red1.TabIndex = 3;
            this.pnl_Red1.Text = "Red";
            this.pnl_Red1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pnl_Yellow1
            // 
            this.pnl_Yellow1.AutoSize = true;
            this.pnl_Yellow1.BackColor = System.Drawing.Color.Yellow;
            this.pnl_Yellow1.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pnl_Yellow1.Location = new System.Drawing.Point(50, 158);
            this.pnl_Yellow1.Name = "pnl_Yellow1";
            this.pnl_Yellow1.Size = new System.Drawing.Size(74, 25);
            this.pnl_Yellow1.TabIndex = 4;
            this.pnl_Yellow1.Text = "Yellow";
            // 
            // btn_Off3
            // 
            this.btn_Off3.ForeColor = System.Drawing.Color.Red;
            this.btn_Off3.Location = new System.Drawing.Point(154, 153);
            this.btn_Off3.Name = "btn_Off3";
            this.btn_Off3.Size = new System.Drawing.Size(60, 34);
            this.btn_Off3.TabIndex = 5;
            this.btn_Off3.Text = "OFF";
            this.btn_Off3.UseVisualStyleBackColor = true;
            this.btn_Off3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_On4
            // 
            this.btn_On4.Location = new System.Drawing.Point(246, 153);
            this.btn_On4.Name = "btn_On4";
            this.btn_On4.Size = new System.Drawing.Size(60, 34);
            this.btn_On4.TabIndex = 6;
            this.btn_On4.Text = "On";
            this.btn_On4.UseVisualStyleBackColor = true;
            // 
            // pnl_Green1
            // 
            this.pnl_Green1.AutoSize = true;
            this.pnl_Green1.BackColor = System.Drawing.Color.Lime;
            this.pnl_Green1.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pnl_Green1.Location = new System.Drawing.Point(54, 236);
            this.pnl_Green1.Name = "pnl_Green1";
            this.pnl_Green1.Size = new System.Drawing.Size(70, 25);
            this.pnl_Green1.TabIndex = 7;
            this.pnl_Green1.Text = "Green";
            // 
            // btn_Off5
            // 
            this.btn_Off5.ForeColor = System.Drawing.Color.Red;
            this.btn_Off5.Location = new System.Drawing.Point(154, 231);
            this.btn_Off5.Name = "btn_Off5";
            this.btn_Off5.Size = new System.Drawing.Size(60, 34);
            this.btn_Off5.TabIndex = 8;
            this.btn_Off5.Text = "OFF";
            this.btn_Off5.UseVisualStyleBackColor = true;
            // 
            // btn_On5
            // 
            this.btn_On5.Location = new System.Drawing.Point(246, 231);
            this.btn_On5.Name = "btn_On5";
            this.btn_On5.Size = new System.Drawing.Size(60, 34);
            this.btn_On5.TabIndex = 9;
            this.btn_On5.Text = "On";
            this.btn_On5.UseVisualStyleBackColor = true;
            // 
            // pnl_Control2
            // 
            this.pnl_Control2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnl_Control2.Controls.Add(this.btn_On7);
            this.pnl_Control2.Controls.Add(this.btn_Off8);
            this.pnl_Control2.Controls.Add(this.pnl_Green2);
            this.pnl_Control2.Controls.Add(this.btn_On9);
            this.pnl_Control2.Controls.Add(this.btn_Off7);
            this.pnl_Control2.Controls.Add(this.pnl_Yellow2);
            this.pnl_Control2.Controls.Add(this.pnl_red2);
            this.pnl_Control2.Controls.Add(this.btn_Off6);
            this.pnl_Control2.Controls.Add(this.DenGiaoThong2);
            this.pnl_Control2.Controls.Add(this.btn_On6);
            this.pnl_Control2.Location = new System.Drawing.Point(614, 196);
            this.pnl_Control2.Name = "pnl_Control2";
            this.pnl_Control2.Size = new System.Drawing.Size(367, 307);
            this.pnl_Control2.TabIndex = 3;
            // 
            // btn_On7
            // 
            this.btn_On7.Location = new System.Drawing.Point(246, 231);
            this.btn_On7.Name = "btn_On7";
            this.btn_On7.Size = new System.Drawing.Size(60, 34);
            this.btn_On7.TabIndex = 9;
            this.btn_On7.Text = "On";
            this.btn_On7.UseVisualStyleBackColor = true;
            // 
            // btn_Off8
            // 
            this.btn_Off8.ForeColor = System.Drawing.Color.Red;
            this.btn_Off8.Location = new System.Drawing.Point(154, 231);
            this.btn_Off8.Name = "btn_Off8";
            this.btn_Off8.Size = new System.Drawing.Size(60, 34);
            this.btn_Off8.TabIndex = 8;
            this.btn_Off8.Text = "OFF";
            this.btn_Off8.UseVisualStyleBackColor = true;
            // 
            // pnl_Green2
            // 
            this.pnl_Green2.AutoSize = true;
            this.pnl_Green2.BackColor = System.Drawing.Color.Lime;
            this.pnl_Green2.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pnl_Green2.Location = new System.Drawing.Point(54, 236);
            this.pnl_Green2.Name = "pnl_Green2";
            this.pnl_Green2.Size = new System.Drawing.Size(70, 25);
            this.pnl_Green2.TabIndex = 7;
            this.pnl_Green2.Text = "Green";
            // 
            // btn_On9
            // 
            this.btn_On9.Location = new System.Drawing.Point(246, 153);
            this.btn_On9.Name = "btn_On9";
            this.btn_On9.Size = new System.Drawing.Size(60, 34);
            this.btn_On9.TabIndex = 6;
            this.btn_On9.Text = "On";
            this.btn_On9.UseVisualStyleBackColor = true;
            // 
            // btn_Off7
            // 
            this.btn_Off7.ForeColor = System.Drawing.Color.Red;
            this.btn_Off7.Location = new System.Drawing.Point(154, 153);
            this.btn_Off7.Name = "btn_Off7";
            this.btn_Off7.Size = new System.Drawing.Size(60, 34);
            this.btn_Off7.TabIndex = 5;
            this.btn_Off7.Text = "OFF";
            this.btn_Off7.UseVisualStyleBackColor = true;
            // 
            // pnl_Yellow2
            // 
            this.pnl_Yellow2.AutoSize = true;
            this.pnl_Yellow2.BackColor = System.Drawing.Color.Yellow;
            this.pnl_Yellow2.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pnl_Yellow2.Location = new System.Drawing.Point(50, 158);
            this.pnl_Yellow2.Name = "pnl_Yellow2";
            this.pnl_Yellow2.Size = new System.Drawing.Size(74, 25);
            this.pnl_Yellow2.TabIndex = 4;
            this.pnl_Yellow2.Text = "Yellow";
            // 
            // pnl_red2
            // 
            this.pnl_red2.AutoSize = true;
            this.pnl_red2.BackColor = System.Drawing.Color.Red;
            this.pnl_red2.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pnl_red2.Location = new System.Drawing.Point(64, 86);
            this.pnl_red2.Name = "pnl_red2";
            this.pnl_red2.Size = new System.Drawing.Size(49, 25);
            this.pnl_red2.TabIndex = 3;
            this.pnl_red2.Text = "Red";
            // 
            // btn_Off6
            // 
            this.btn_Off6.ForeColor = System.Drawing.Color.Red;
            this.btn_Off6.Location = new System.Drawing.Point(154, 81);
            this.btn_Off6.Name = "btn_Off6";
            this.btn_Off6.Size = new System.Drawing.Size(60, 34);
            this.btn_Off6.TabIndex = 2;
            this.btn_Off6.Text = "OFF";
            this.btn_Off6.UseVisualStyleBackColor = true;
            // 
            // DenGiaoThong2
            // 
            this.DenGiaoThong2.AutoSize = true;
            this.DenGiaoThong2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.DenGiaoThong2.Location = new System.Drawing.Point(38, 16);
            this.DenGiaoThong2.Name = "DenGiaoThong2";
            this.DenGiaoThong2.Size = new System.Drawing.Size(295, 41);
            this.DenGiaoThong2.TabIndex = 0;
            this.DenGiaoThong2.Text = "Den Giao Thong 2";
            // 
            // btn_On6
            // 
            this.btn_On6.Location = new System.Drawing.Point(246, 81);
            this.btn_On6.Name = "btn_On6";
            this.btn_On6.Size = new System.Drawing.Size(60, 34);
            this.btn_On6.TabIndex = 1;
            this.btn_On6.Text = "On";
            this.btn_On6.UseVisualStyleBackColor = true;
            // 
            // Control
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 593);
            this.Controls.Add(this.pnl_Control2);
            this.Controls.Add(this.pnl_Control1);
            this.Controls.Add(this.pnl_quanli);
            this.Name = "Control";
            this.Text = "FrmWifi";
            this.pnl_quanli.ResumeLayout(false);
            this.pnl_setting.ResumeLayout(false);
            this.pnl_setting.PerformLayout();
            this.pnl_help.ResumeLayout(false);
            this.pnl_help.PerformLayout();
            this.pnl_Control1.ResumeLayout(false);
            this.pnl_Control1.PerformLayout();
            this.pnl_Control2.ResumeLayout(false);
            this.pnl_Control2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ColorDialog colorDialog1;
        private Panel pnl_quanli;
        private Panel pnl_help;
        private Label pnl_help1;
        private Panel pnl_setting;
        private Label pnl_Setting1;
        private Button btn_On1;
        private Panel pnl_Control1;
        private Label DenGiaoThong1;
        private Label pnl_Red1;
        private Button btn_Off2;
        private Button btn_Off3;
        private Label pnl_Yellow1;
        private Button btn_On5;
        private Button btn_Off5;
        private Label pnl_Green1;
        private Button btn_On4;
        private Panel pnl_Control2;
        private Button btn_On7;
        private Button btn_Off8;
        private Label pnl_Green2;
        private Button btn_On9;
        private Button btn_Off7;
        private Label pnl_Yellow2;
        private Label pnl_red2;
        private Button btn_Off6;
        private Label DenGiaoThong2;
        private Button btn_On6;
    }
}